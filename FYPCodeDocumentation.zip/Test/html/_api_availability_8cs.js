var _api_availability_8cs =
[
    [ "ApiAvailability", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9", [
      [ "UnknownError", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9abfaef30f1c8011c5cefa38ae470fb7aa", null ],
      [ "UnknownChecking", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9aa013ea338357a0ece978409b9be5c4cb", null ],
      [ "UnknownTimedOut", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9aeda4fec20c793119da905399a308ee1b", null ],
      [ "UnsupportedDeviceNotCapable", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9af3c56151dad994181cf4206c37a3b497", null ],
      [ "SupportedNotInstalled", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9a80487b3c21041f2830b80eeb2d5ca354", null ],
      [ "SupportedApkTooOld", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9a713ba44b6208e4723cc79328923cef98", null ],
      [ "SupportedInstalled", "_api_availability_8cs.html#a1dafc94c17e1c86c528ceefb5b1533f9a819791623c386efabd411ca83909b714", null ]
    ] ]
];