var _api_trackable_type_8cs =
[
    [ "ApiTrackableType", "_api_trackable_type_8cs.html#a564f382b5fae0c54eca7ce09bfee7231", [
      [ "Invalid", "_api_trackable_type_8cs.html#a564f382b5fae0c54eca7ce09bfee7231a4bbb8f967da6d1a610596d7257179c2b", null ],
      [ "BaseTrackable", "_api_trackable_type_8cs.html#a564f382b5fae0c54eca7ce09bfee7231af5ae67bdf33f2859008cbfa7dc322ce8", null ],
      [ "Plane", "_api_trackable_type_8cs.html#a564f382b5fae0c54eca7ce09bfee7231a0d3adee051531c15b3509b4d4d75ce7b", null ],
      [ "Point", "_api_trackable_type_8cs.html#a564f382b5fae0c54eca7ce09bfee7231a2a3cd5946cfd317eb99c3d32e35e2d4c", null ],
      [ "AugmentedImage", "_api_trackable_type_8cs.html#a564f382b5fae0c54eca7ce09bfee7231a0d9134c3c12b6c2c3c1c306ce93bb431", null ]
    ] ]
];