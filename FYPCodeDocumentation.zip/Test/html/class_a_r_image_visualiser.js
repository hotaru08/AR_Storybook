var class_a_r_image_visualiser =
[
    [ "m_debugText", "class_a_r_image_visualiser.html#a7868b7b57837f8f68c0b2d08bab11ca1", null ],
    [ "m_image", "class_a_r_image_visualiser.html#aa5b77d6ec10436d6c005a1aca19bc0b4", null ],
    [ "m_objectList", "class_a_r_image_visualiser.html#a0e7c9e113816ac20a1cd14c41817efac", null ]
];