var _api_update_mode_8cs =
[
    [ "ApiUpdateMode", "_api_update_mode_8cs.html#a4ff8a1c68dc2675a3e81001eeef539b5", [
      [ "Blocking", "_api_update_mode_8cs.html#a4ff8a1c68dc2675a3e81001eeef539b5abd0ca6be53b0f3d2886fd53fcb52574e", null ],
      [ "LatestCameraImage", "_api_update_mode_8cs.html#a4ff8a1c68dc2675a3e81001eeef539b5a4e8a3a4278439b3e608f03da9c0abeba", null ]
    ] ]
];