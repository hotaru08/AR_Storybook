var _light_estimate_state_8cs =
[
    [ "LightEstimateState", "_light_estimate_state_8cs.html#aa0e52b452ba689516d3e2bf5921a9ab7", [
      [ "NotValid", "_light_estimate_state_8cs.html#aa0e52b452ba689516d3e2bf5921a9ab7a04665ec171e86ef749cc563d7bdeec91", null ],
      [ "Valid", "_light_estimate_state_8cs.html#aa0e52b452ba689516d3e2bf5921a9ab7a3ac705f2acd51a4613f9188c05c91d0d", null ]
    ] ]
];