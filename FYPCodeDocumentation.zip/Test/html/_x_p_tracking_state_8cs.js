var _x_p_tracking_state_8cs =
[
    [ "XPTrackingState", "_x_p_tracking_state_8cs.html#adf7e3ff0cb68d7c0f90558f176d781bd", [
      [ "Tracking", "_x_p_tracking_state_8cs.html#adf7e3ff0cb68d7c0f90558f176d781bda2205dc082ba550b67ad71e3e2241d9a6", null ],
      [ "Paused", "_x_p_tracking_state_8cs.html#adf7e3ff0cb68d7c0f90558f176d781bdae99180abf47a8b3a856e0bcb2656990a", null ],
      [ "Stopped", "_x_p_tracking_state_8cs.html#adf7e3ff0cb68d7c0f90558f176d781bdac23e2b09ebe6bf4cb5e2a9abe85c0be2", null ]
    ] ]
];