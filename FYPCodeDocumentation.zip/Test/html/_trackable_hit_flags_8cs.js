var _trackable_hit_flags_8cs =
[
    [ "TrackableHitFlags", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ff", [
      [ "None", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffa6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "PlaneWithinPolygon", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffa0b28352d68f15f6fef269c19d4b6f0b2", null ],
      [ "PlaneWithinBounds", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffaf52f57e6ca008a1b376cd719551c0603", null ],
      [ "PlaneWithinInfinity", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffa7020f4c83b59755b8463b2e8e5a74a80", null ],
      [ "FeaturePoint", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffa81d66952d59b5de41234e779a33a4870", null ],
      [ "FeaturePointWithSurfaceNormal", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffa598b6dd1a4889909abcfb9df34d98e94", null ],
      [ "Default", "_trackable_hit_flags_8cs.html#a8da5a2395bdef6ffe411700df5a713ffa7a1920d61156abc05a60135aefe8bc67", null ]
    ] ]
];