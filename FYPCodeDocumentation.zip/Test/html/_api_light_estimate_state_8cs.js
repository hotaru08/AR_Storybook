var _api_light_estimate_state_8cs =
[
    [ "ApiLightEstimateState", "_api_light_estimate_state_8cs.html#a16dfc859d54afa7f0ad100008ecc8768", [
      [ "NotValid", "_api_light_estimate_state_8cs.html#a16dfc859d54afa7f0ad100008ecc8768a04665ec171e86ef749cc563d7bdeec91", null ],
      [ "Valid", "_api_light_estimate_state_8cs.html#a16dfc859d54afa7f0ad100008ecc8768a3ac705f2acd51a4613f9188c05c91d0d", null ]
    ] ]
];