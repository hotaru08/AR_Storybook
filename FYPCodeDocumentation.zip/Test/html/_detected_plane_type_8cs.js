var _detected_plane_type_8cs =
[
    [ "DetectedPlaneType", "_detected_plane_type_8cs.html#ac337b52f5b4321fe1199d26e9d6e3517", [
      [ "HorizontalUpwardFacing", "_detected_plane_type_8cs.html#ac337b52f5b4321fe1199d26e9d6e3517aff7f5d2876c8408656f721ca947419af", null ],
      [ "HorizontalDownwardFacing", "_detected_plane_type_8cs.html#ac337b52f5b4321fe1199d26e9d6e3517a3ec02bf5e110fb082c3c5b46b54256bc", null ],
      [ "Vertical", "_detected_plane_type_8cs.html#ac337b52f5b4321fe1199d26e9d6e3517a06ce2a25e5d12c166a36f654dbea6012", null ]
    ] ]
];