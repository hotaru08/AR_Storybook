var _api_presto_status_8cs =
[
    [ "ApiPrestoStatus", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8a", [
      [ "Uninitialized", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aaf704f57ea420275ad51bf55b7dec2c96", null ],
      [ "RequestingApkInstall", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa6dafa02dab12b8bf12d0695f66f33748", null ],
      [ "RequestingPermission", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa6b8d7f54908a986bb788e94792c892d8", null ],
      [ "Resumed", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aab2a21932ddc3b1e41c012d711c7bd238", null ],
      [ "ResumedNotTracking", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa11af52ff9290ac043e94945c71c899a1", null ],
      [ "Paused", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aae99180abf47a8b3a856e0bcb2656990a", null ],
      [ "ErrorFatal", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa59b57627dca66292e3946cd10b317552", null ],
      [ "ErrorApkNotAvailable", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa501c3f690fb135312003c50b2ad446a9", null ],
      [ "ErrorPermissionNotGranted", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa07c5480bae8819d7124ba07b0e23dd34", null ],
      [ "ErrorSessionConfigurationNotSupported", "_api_presto_status_8cs.html#a0619e505d013e8bc56987c88d5e49e8aa45ce58976d62af1dc8231e73183ba358", null ]
    ] ]
];