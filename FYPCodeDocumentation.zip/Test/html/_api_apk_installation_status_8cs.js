var _api_apk_installation_status_8cs =
[
    [ "ApiApkInstallationStatus", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8", [
      [ "Uninitialized", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8af704f57ea420275ad51bf55b7dec2c96", null ],
      [ "Requested", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8afcdf8a82eba24e303b63b2e49a507ecb", null ],
      [ "Success", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8a505a83f220c02df2f85c3810cd9ceb38", null ],
      [ "Error", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8a902b0d55fddef6f8d651fe1035b7d4bd", null ],
      [ "ErrorDeviceNotCompatible", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8aa4f5f24761b409319e50fbeea21970d4", null ],
      [ "ErrorUserDeclined", "_api_apk_installation_status_8cs.html#ad846a0f70311de1b1ca0eef5615dbbd8a94061e280a8dc3a9f5aa408aa75e4ef4", null ]
    ] ]
];