var _api_feature_point_orientation_mode_8cs =
[
    [ "ApiFeaturePointOrientationMode", "_api_feature_point_orientation_mode_8cs.html#a321250709d08a4e8b8d4b042578de75b", [
      [ "Identity", "_api_feature_point_orientation_mode_8cs.html#a321250709d08a4e8b8d4b042578de75bac9c5c65fb4af9cf90eb99b3b84424189", null ],
      [ "SurfaceNormal", "_api_feature_point_orientation_mode_8cs.html#a321250709d08a4e8b8d4b042578de75babda2a99e07284ff95b14c05e69f18239", null ]
    ] ]
];