var _apk_installation_status_8cs =
[
    [ "ApkInstallationStatus", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9", [
      [ "Uninitialized", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9af704f57ea420275ad51bf55b7dec2c96", null ],
      [ "Requested", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9afcdf8a82eba24e303b63b2e49a507ecb", null ],
      [ "Success", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9a505a83f220c02df2f85c3810cd9ceb38", null ],
      [ "Error", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9a902b0d55fddef6f8d651fe1035b7d4bd", null ],
      [ "ErrorDeviceNotCompatible", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9aa4f5f24761b409319e50fbeea21970d4", null ],
      [ "ErrorAndroidVersionNotSupported", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9a7d143912696a3db172161c3ca254adbf", null ],
      [ "ErrorUserDeclined", "_apk_installation_status_8cs.html#a3af027504929047e8e4b156562953ee9a94061e280a8dc3a9f5aa408aa75e4ef4", null ]
    ] ]
];