var class_a_i___health_bar =
[
    [ "DAMAGE_MODE", "class_a_i___health_bar.html#afacec75c49fbb5be9e173744918dd361", [
      [ "NONE", "class_a_i___health_bar.html#afacec75c49fbb5be9e173744918dd361ab50339a10e1de285ac99d4c3990b8693", null ],
      [ "DAMAGED_BASED", "class_a_i___health_bar.html#afacec75c49fbb5be9e173744918dd361a6937a2b2086e9e64c8938d8b6fc21f50", null ],
      [ "TIME_BASED", "class_a_i___health_bar.html#afacec75c49fbb5be9e173744918dd361a7b13ca71d545e3fb822b4c90a876bb83", null ]
    ] ],
    [ "IncreaseEnemyHealth", "class_a_i___health_bar.html#a4e2de4fed31cc2fd13d142c775e37171", null ],
    [ "ReduceEnemyHealth", "class_a_i___health_bar.html#af2dad69cdceb21fa75e849b2090dbc43", null ],
    [ "ResetEnemyHealth", "class_a_i___health_bar.html#ae60479c3bd1bba4c7f87c6bbb6820059", null ],
    [ "m_mode", "class_a_i___health_bar.html#acf563e299ce90e63f98f016d2d28a3a0", null ]
];