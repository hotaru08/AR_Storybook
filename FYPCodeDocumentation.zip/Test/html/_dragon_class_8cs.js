var _dragon_class_8cs =
[
    [ "DragonClass", "class_letterbox_camera_1_1_dragon_class.html", "class_letterbox_camera_1_1_dragon_class" ],
    [ "Feed", "_dragon_class_8cs.html#aa883966c4fc9dcdf09644c810db7e881", [
      [ "Meat", "_dragon_class_8cs.html#aa883966c4fc9dcdf09644c810db7e881ae4b662d3892f8c0c86801919f979467f", null ],
      [ "Fruit", "_dragon_class_8cs.html#aa883966c4fc9dcdf09644c810db7e881a3b26194b13edb91ea719ef5cbee8d5bd", null ]
    ] ]
];