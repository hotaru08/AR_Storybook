var _api_camera_metadata_8cs =
[
    [ "NdkCameraMetadataType", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5", [
      [ "Byte", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5aa245c3230debe5c956484ecc6fa93877", null ],
      [ "Int32", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5ac06129f6e6e15c09328365e553f1dc31", null ],
      [ "Float", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5a22ae0e2b89e5e3d477f988cc36d3272b", null ],
      [ "Int64", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5afbde23b11d7e59af7828e81144c8b487", null ],
      [ "Double", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5ad909d38d705ce75386dd86e611a82f5b", null ],
      [ "Rational", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5a1987a88c6ff10363e43d25ead3066ad8", null ],
      [ "NumTypes", "_api_camera_metadata_8cs.html#af9e0ba7d1a7791601f0fe90bce3acdf5a86e30d8e0831512671e7ed103ad7c457", null ]
    ] ],
    [ "NdkCameraStatus", "_api_camera_metadata_8cs.html#a1f352d4b02da7b96a7f26215e33b53e6", [
      [ "Ok", "_api_camera_metadata_8cs.html#a1f352d4b02da7b96a7f26215e33b53e6aa60852f204ed8028c1c58808b746d115", null ],
      [ "ErrorBase", "_api_camera_metadata_8cs.html#a1f352d4b02da7b96a7f26215e33b53e6a0f3d563ba0059add29d47cde1cd35449", null ],
      [ "ErrorUnknown", "_api_camera_metadata_8cs.html#a1f352d4b02da7b96a7f26215e33b53e6a3cabc605300c5d86602e943fcf77672b", null ],
      [ "ErrorInvalidParameter", "_api_camera_metadata_8cs.html#a1f352d4b02da7b96a7f26215e33b53e6ad5e149319779149564a5392939ea8683", null ],
      [ "ErrorMetadataNotFound", "_api_camera_metadata_8cs.html#a1f352d4b02da7b96a7f26215e33b53e6a4be3e935cf73c5a1997c8162ed0f930b", null ]
    ] ]
];