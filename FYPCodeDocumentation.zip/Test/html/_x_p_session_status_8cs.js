var _x_p_session_status_8cs =
[
    [ "XPSessionStatus", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2", [
      [ "None", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Initializing", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a32b169f72b293ef80d35435e9894f8e2", null ],
      [ "Tracking", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a2205dc082ba550b67ad71e3e2241d9a6", null ],
      [ "LostTracking", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a2905b90635c3998b7aa89d4555277922", null ],
      [ "NotTracking", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a7d16123e4cbbeffacd9a0db5cdab945a", null ],
      [ "FatalError", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2af245a0dc66dc8cd7d835771034eb4b86", null ],
      [ "ErrorApkNotAvailable", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a501c3f690fb135312003c50b2ad446a9", null ],
      [ "ErrorPermissionNotGranted", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a07c5480bae8819d7124ba07b0e23dd34", null ],
      [ "ErrorSessionConfigurationNotSupported", "_x_p_session_status_8cs.html#a2321a1945ee767052ec949b4774126a2a45ce58976d62af1dc8231e73183ba358", null ]
    ] ]
];