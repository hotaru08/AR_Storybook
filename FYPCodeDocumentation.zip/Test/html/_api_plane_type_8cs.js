var _api_plane_type_8cs =
[
    [ "ApiPlaneType", "_api_plane_type_8cs.html#a58785d3d32f20da6f0f299aa7327f525", [
      [ "HorizontalUpwardFacing", "_api_plane_type_8cs.html#a58785d3d32f20da6f0f299aa7327f525aff7f5d2876c8408656f721ca947419af", null ],
      [ "HorizontalDownwardFacing", "_api_plane_type_8cs.html#a58785d3d32f20da6f0f299aa7327f525a3ec02bf5e110fb082c3c5b46b54256bc", null ],
      [ "Vertical", "_api_plane_type_8cs.html#a58785d3d32f20da6f0f299aa7327f525a06ce2a25e5d12c166a36f654dbea6012", null ]
    ] ]
];