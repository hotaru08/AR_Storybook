var _api_cloud_anchor_state_8cs =
[
    [ "ApiCloudAnchorState", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526", [
      [ "None", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "TaskInProgress", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a6d33471818188098b9545d2a253a1288", null ],
      [ "Success", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a505a83f220c02df2f85c3810cd9ceb38", null ],
      [ "ErrorInternal", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526aa4b8fe38709fba050b2ba197c8805053", null ],
      [ "ErrorNotAuthorized", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526aa8f53859803f23fde1ea0c40d2686b90", null ],
      [ "ErrorServiceUnavailable", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a8fdbf845e7d286a1b947fb08ba4982d5", null ],
      [ "ErrorResourceExhausted", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a234626659ec02c8be1d80c19acb96953", null ],
      [ "ErrorHostingDatasetProcessingFailed", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a6e469255cd9866cc1ba5bd559d69d092", null ],
      [ "ErrorResolveingCloudIdNotFound", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526ad245cc5a290477ceae7b8027aec310f6", null ],
      [ "ErrorResolvingLocalizationNoMatch", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a51d0d1898241f71a580f2ef7c9d6398f", null ],
      [ "ErrorResolvingSDKTooOld", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526af54a737fedeecf0c3e09ed431397b620", null ],
      [ "ErrorResolvingSDKTooNew", "_api_cloud_anchor_state_8cs.html#acf97af0a21839c11506d29c3a90a1526a9a20f0cbc7f4363fedc158e62969c650", null ]
    ] ]
];