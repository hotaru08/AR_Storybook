var _api_ar_status_8cs =
[
    [ "ApiArStatus", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45b", [
      [ "Success", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba505a83f220c02df2f85c3810cd9ceb38", null ],
      [ "ErrorInvalidArgument", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45baf1d2c1de23e3321cb2048c8024250e2a", null ],
      [ "ErrorFatal", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba59b57627dca66292e3946cd10b317552", null ],
      [ "ErrorSessionPaused", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba353395cbce0eb3bbcecc4f3f898aeeea", null ],
      [ "ErrorSessionNotPaused", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba4b0e19f20eb88741e165e91a0cf22b97", null ],
      [ "ErrorNotTracking", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba280ee9c537f4c1dde73c5e2cc4c30808", null ],
      [ "ErrorTextureNotSet", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba5d8df9ec9b23baa9ed4d913c3bab9b1b", null ],
      [ "ErrorMissingGlContext", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45bae64ff502b11753c32599b7a217556445", null ],
      [ "ErrorUnsupportedConfiguration", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45babf2613121046e61596828ad879bffd5a", null ],
      [ "ErrorCameraPermissionNotGranted", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba76eb5cf3a02a5af6fdb757fb2e02996f", null ],
      [ "ErrorDeadlineExceeded", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45baaf3637eccfe6555757a5054c9c1ef983", null ],
      [ "ErrorResourceExhausted", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba234626659ec02c8be1d80c19acb96953", null ],
      [ "ErrorNotYetAvailable", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45bac8099a260502ff9b684ac30ff00e479f", null ],
      [ "ErrorCameraNotAvailable", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba136c1093dfcce32496789900fe5514f2", null ],
      [ "ErrorCloudAnchorsNotConfigured", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45bab1a0dd4aa345ae7155ce15ea126a8d45", null ],
      [ "ErrorInternetPermissionNotGranted", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45baa51c790ed7085a8f08b6f384e09f41de", null ],
      [ "ErrorAnchorNotSupportedForHosting", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba4ec5a90be8b1213f008198ef5eb052df", null ],
      [ "ErrorImageInsufficientQuality", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45bac08ac6a8dbeda6f9c78908b170d3a971", null ],
      [ "ErrorDataInvalidFormat", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba4880b8400085873c670f789f4a0d78e2", null ],
      [ "ErrorDatatUnsupportedVersion", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45bacfc243894c576b1e588aace64f6dd91c", null ],
      [ "UnavailableArCoreNotInstalled", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45baad746360419552797eaa46126e52faa6", null ],
      [ "UnavailableDeviceNotCompatible", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45baa63b80d04c6383737d0f164bdb106717", null ],
      [ "UnavailableApkTooOld", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba17be894f8af185705c4d3954249c718d", null ],
      [ "UnavailableSdkTooOld", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba5d60fa25e7122c05b6f75f31e8d850d4", null ],
      [ "UnavailableUserDeclinedInstall", "_api_ar_status_8cs.html#a0871a374772911500b3e86357aefa45ba795b6aac9075c5de77d97fe62152f609", null ]
    ] ]
];