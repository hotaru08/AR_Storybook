var _tracked_point_orientation_mode_8cs =
[
    [ "TrackedPointOrientationMode", "_tracked_point_orientation_mode_8cs.html#a7b36c2190e68698b3e3565b5a0b2a669", [
      [ "Identity", "_tracked_point_orientation_mode_8cs.html#a7b36c2190e68698b3e3565b5a0b2a669ac9c5c65fb4af9cf90eb99b3b84424189", null ],
      [ "SurfaceNormal", "_tracked_point_orientation_mode_8cs.html#a7b36c2190e68698b3e3565b5a0b2a669abda2a99e07284ff95b14c05e69f18239", null ]
    ] ]
];