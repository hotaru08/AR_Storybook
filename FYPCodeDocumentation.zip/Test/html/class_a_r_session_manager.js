var class_a_r_session_manager =
[
    [ "GetSession", "class_a_r_session_manager.html#a3dd79b21d0fe08f387bbcbd18e6b09dd", null ],
    [ "ResetSession", "class_a_r_session_manager.html#aa0341574b0e886f603558bbab1b1e9e5", null ]
];