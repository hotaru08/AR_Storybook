var _menu_spin_8cs =
[
    [ "MenuSpin", "class_letterbox_camera_1_1_menu_spin.html", "class_letterbox_camera_1_1_menu_spin" ],
    [ "rotAxis", "_menu_spin_8cs.html#a008da8a1257c495d8245459c702143cf", [
      [ "xAxis", "_menu_spin_8cs.html#a008da8a1257c495d8245459c702143cfab919a806dedef37999b45653bdde66c6", null ],
      [ "yAxis", "_menu_spin_8cs.html#a008da8a1257c495d8245459c702143cfaf3cd431f5ac1725ea18774e5c02f2889", null ],
      [ "zAxis", "_menu_spin_8cs.html#a008da8a1257c495d8245459c702143cfa92d83a9e615f2c1223d73c3e9a332597", null ]
    ] ]
];