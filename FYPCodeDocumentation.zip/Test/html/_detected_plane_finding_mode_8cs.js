var _detected_plane_finding_mode_8cs =
[
    [ "DetectedPlaneFindingMode", "_detected_plane_finding_mode_8cs.html#a730a9df53b81465642e5e9204d6a78dd", [
      [ "Disabled", "_detected_plane_finding_mode_8cs.html#a730a9df53b81465642e5e9204d6a78ddab9f5c797ebbf55adccdd8539a65a0241", null ],
      [ "HorizontalAndVertical", "_detected_plane_finding_mode_8cs.html#a730a9df53b81465642e5e9204d6a78dda8a4ec9cfaa0a4f67a270b8741f45184b", null ],
      [ "Horizontal", "_detected_plane_finding_mode_8cs.html#a730a9df53b81465642e5e9204d6a78ddac1b5fa03ecdb95d4a45dd1c40b02527f", null ],
      [ "Vertical", "_detected_plane_finding_mode_8cs.html#a730a9df53b81465642e5e9204d6a78dda06ce2a25e5d12c166a36f654dbea6012", null ]
    ] ]
];