var _api_tracking_state_8cs =
[
    [ "ApiTrackingState", "_api_tracking_state_8cs.html#a194a9e9105c32b154e6dd44d332188fa", [
      [ "Tracking", "_api_tracking_state_8cs.html#a194a9e9105c32b154e6dd44d332188faa2205dc082ba550b67ad71e3e2241d9a6", null ],
      [ "Paused", "_api_tracking_state_8cs.html#a194a9e9105c32b154e6dd44d332188faae99180abf47a8b3a856e0bcb2656990a", null ],
      [ "Stopped", "_api_tracking_state_8cs.html#a194a9e9105c32b154e6dd44d332188faac23e2b09ebe6bf4cb5e2a9abe85c0be2", null ]
    ] ]
];