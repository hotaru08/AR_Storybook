var _terrain_segment_8cs =
[
    [ "TerrainSegment", "class_letterbox_camera_1_1_terrain_segment.html", "class_letterbox_camera_1_1_terrain_segment" ],
    [ "UVMappingMode", "_terrain_segment_8cs.html#a32e6468d1572809f66fbc141c8e45d06", [
      [ "STRETCH_MATCH", "_terrain_segment_8cs.html#a32e6468d1572809f66fbc141c8e45d06a3a08e516bfc0b5b413978fa4a2ae33e6", null ],
      [ "TILING", "_terrain_segment_8cs.html#a32e6468d1572809f66fbc141c8e45d06a67ed8e0a405a589b57450f909a84075a", null ]
    ] ]
];