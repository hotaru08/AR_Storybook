var _api_plane_finding_mode_8cs =
[
    [ "ApiPlaneFindingMode", "_api_plane_finding_mode_8cs.html#a08bb08f897378837d57cac0dba207f7f", [
      [ "Disabled", "_api_plane_finding_mode_8cs.html#a08bb08f897378837d57cac0dba207f7fab9f5c797ebbf55adccdd8539a65a0241", null ],
      [ "Horizontal", "_api_plane_finding_mode_8cs.html#a08bb08f897378837d57cac0dba207f7fac1b5fa03ecdb95d4a45dd1c40b02527f", null ],
      [ "Vertical", "_api_plane_finding_mode_8cs.html#a08bb08f897378837d57cac0dba207f7fa06ce2a25e5d12c166a36f654dbea6012", null ],
      [ "HorizontalAndVertical", "_api_plane_finding_mode_8cs.html#a08bb08f897378837d57cac0dba207f7fa8a4ec9cfaa0a4f67a270b8741f45184b", null ]
    ] ]
];