var _api_camera_focus_mode_8cs =
[
    [ "ApiCameraFocusMode", "_api_camera_focus_mode_8cs.html#ada5d52f2424f205cb4fa5d8ae109e0d0", [
      [ "Fixed", "_api_camera_focus_mode_8cs.html#ada5d52f2424f205cb4fa5d8ae109e0d0a4457d440870ad6d42bab9082d9bf9b61", null ],
      [ "Auto", "_api_camera_focus_mode_8cs.html#ada5d52f2424f205cb4fa5d8ae109e0d0a06b9281e396db002010bde1de57262eb", null ]
    ] ]
];