var _apk_availability_status_8cs =
[
    [ "ApkAvailabilityStatus", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2", [
      [ "UnknownError", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2abfaef30f1c8011c5cefa38ae470fb7aa", null ],
      [ "UnknownChecking", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2aa013ea338357a0ece978409b9be5c4cb", null ],
      [ "UnknownTimedOut", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2aeda4fec20c793119da905399a308ee1b", null ],
      [ "UnsupportedDeviceNotCapable", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2af3c56151dad994181cf4206c37a3b497", null ],
      [ "SupportedNotInstalled", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2a80487b3c21041f2830b80eeb2d5ca354", null ],
      [ "SupportedApkTooOld", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2a713ba44b6208e4723cc79328923cef98", null ],
      [ "SupportedInstalled", "_apk_availability_status_8cs.html#a222298fe80423f5bee38006a36ea09e2a819791623c386efabd411ca83909b714", null ]
    ] ]
];