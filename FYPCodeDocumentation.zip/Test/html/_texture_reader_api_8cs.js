var _texture_reader_api_8cs =
[
    [ "TextureReaderApi", "class_google_a_r_core_1_1_examples_1_1_computer_vision_1_1_texture_reader_api.html", "class_google_a_r_core_1_1_examples_1_1_computer_vision_1_1_texture_reader_api" ],
    [ "AndroidImport", "_texture_reader_api_8cs.html#a7fc588a4c9877cce593f7470beaa8b6a", null ],
    [ "IOSImport", "_texture_reader_api_8cs.html#adb786fd5063f7cd2e2c67fb43621ab83", null ]
];