var _camera_focus_mode_8cs =
[
    [ "CameraFocusMode", "_camera_focus_mode_8cs.html#aa51eca67ee18561dcc27850ca02c5616", [
      [ "Fixed", "_camera_focus_mode_8cs.html#aa51eca67ee18561dcc27850ca02c5616a4457d440870ad6d42bab9082d9bf9b61", null ],
      [ "Auto", "_camera_focus_mode_8cs.html#aa51eca67ee18561dcc27850ca02c5616a06b9281e396db002010bde1de57262eb", null ]
    ] ]
];