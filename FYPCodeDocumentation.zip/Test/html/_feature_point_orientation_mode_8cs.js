var _feature_point_orientation_mode_8cs =
[
    [ "FeaturePointOrientationMode", "_feature_point_orientation_mode_8cs.html#a36a02a2579c689d47a9cd6a7e1f782c1", [
      [ "Identity", "_feature_point_orientation_mode_8cs.html#a36a02a2579c689d47a9cd6a7e1f782c1ac9c5c65fb4af9cf90eb99b3b84424189", null ],
      [ "SurfaceNormal", "_feature_point_orientation_mode_8cs.html#a36a02a2579c689d47a9cd6a7e1f782c1abda2a99e07284ff95b14c05e69f18239", null ]
    ] ]
];