var _tracking_state_8cs =
[
    [ "TrackingState", "_tracking_state_8cs.html#a938c1d7c45703a54eb3360e112e38646", [
      [ "Tracking", "_tracking_state_8cs.html#a938c1d7c45703a54eb3360e112e38646a2205dc082ba550b67ad71e3e2241d9a6", null ],
      [ "Paused", "_tracking_state_8cs.html#a938c1d7c45703a54eb3360e112e38646ae99180abf47a8b3a856e0bcb2656990a", null ],
      [ "Stopped", "_tracking_state_8cs.html#a938c1d7c45703a54eb3360e112e38646ac23e2b09ebe6bf4cb5e2a9abe85c0be2", null ]
    ] ]
];