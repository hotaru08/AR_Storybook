var _api_light_estimation_mode_8cs =
[
    [ "ApiLightEstimationMode", "_api_light_estimation_mode_8cs.html#a77455c0b3b1c3b06a4872bd2d7b03c86", [
      [ "Disabled", "_api_light_estimation_mode_8cs.html#a77455c0b3b1c3b06a4872bd2d7b03c86ab9f5c797ebbf55adccdd8539a65a0241", null ],
      [ "AmbientIntensity", "_api_light_estimation_mode_8cs.html#a77455c0b3b1c3b06a4872bd2d7b03c86adff13b74e90d98647e64c8607b620c34", null ]
    ] ]
];