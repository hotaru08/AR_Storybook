var _cloud_service_response_8cs =
[
    [ "CloudServiceResponse", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728", [
      [ "Success", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728a505a83f220c02df2f85c3810cd9ceb38", null ],
      [ "ErrorNotSupportedByConfiguration", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728aad97c4e6b4f9dc59a56f128cfcde0f2b", null ],
      [ "ErrorNotTracking", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728a280ee9c537f4c1dde73c5e2cc4c30808", null ],
      [ "ErrorServiceUnreachable", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728aff13cb70dfea630c8ccf9515a2ee3fbd", null ],
      [ "ErrorNotAuthorized", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728aa8f53859803f23fde1ea0c40d2686b90", null ],
      [ "ErrorApiQuotaExceeded", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728acc944b03d5425b95b34b3575a5e5f6fe", null ],
      [ "ErrorDatasetInadequate", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728a9f96762b5cde1291135b4a0778db3052", null ],
      [ "ErrorCloudIdNotFound", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728a6a6b16e36c04b1a1000493b3445f2188", null ],
      [ "ErrorLocalizationFailed", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728ab7454f9001add6e3b7bf653661c78a7a", null ],
      [ "ErrorSDKTooOld", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728a3c402b1bc08f327029b77234f6a67d40", null ],
      [ "ErrorSDKTooNew", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728a7b6637d4d39f3465bfeb133172166554", null ],
      [ "ErrorInternal", "_cloud_service_response_8cs.html#a0cf87ca12d1da2327d132a7d893ac728aa4b8fe38709fba050b2ba197c8805053", null ]
    ] ]
];